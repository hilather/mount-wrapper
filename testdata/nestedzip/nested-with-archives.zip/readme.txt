top-level readme for nestedzip fixture
